/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jobapplicationtracker;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.SpringLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.PrintWriter;
/**
 *
 * @author Samuel
 */
// the class header...
//This class is being establised as a program that will display in a frame within the operating system
//      and will have access to a window listener should the user wish to close the frame.
public class JobApplicationTracker extends Frame implements WindowListener, ActionListener
{
    // SOME BACKGROUND INFORMATION:
    // An BirthdayRecords.txt data file has been added to the directory of this update.
    // If using NetBeans as your IDE, this file might be copied into the IPAddressDatabase project
    //     folder (within your Netbeans project folder), but placed outside the project's src folder.
    // The IPAddressDatabase application will load all the data from the data file and
    //     place a copy into RAM memory (or equivalent).  Then the first record (line/entry)
    //     of this data will be displayed on screen.
    // Six arrays are being introduced in this update to store the data from the data file
    //     within RAM memory.


    // DECLARATIONS --------------------------------------------------------------------------
    int maxApplications = 500;     //Global variable to define the maximum size of the six arrays
    int numberOfApplications = 0;  //Global variable to remember how many actual entries are currently in the 6 arrays
    int currentApplication = 0;       //Global variable to remeber which entry in the array we are currently focused on
    
    // Declare the array for storing the Birthdaqy data in memory - each has a maximum size of 
    //      maxBirthdays (currently equal to 100 entries)
    String[] applicationDate = new String[maxApplications]; 
    String[] applicationCompany = new String[maxApplications];
    String[] applicationPhoneNumber = new String[maxApplications];
    String[] applicationEmail = new String[maxApplications];
    String[] applicationAddress = new String[maxApplications];
    String[] applicationDescription = new String[maxApplications];
    //String[] recordYear = new String[maxApplications];
    // Declare the Buttons, TextFields and Labels that will be needed in program
    Button btnNew, btnFind, btnSave, btnDelete, btnExit, btnNext, btnPrevious, btnFirst, btnLast;
    TextField txtDate, txtCompany, txtPhoneNumber,txtEmail, txtAddress, txtDescription, txtFind;
    Label lblFind, lblDate, lblCompany, lblPhoneNumber, lblEmail, lblAddress, lblDescription;
    
    //Main entry point to the class and application
    //String[] args allows the user to type in additional parameters on the console when first
    //      running the program. this feature is not utilised in this program.
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Declares and instantiates the Frame and in so doing, calls the: public BirthdayTracker
        //      constructor below.  The additional code lines set the various properties of the Frame
       Frame myFrame = new JobApplicationTracker();
       myFrame.setSize(420,350);
       myFrame.setLocation(400, 200);
       myFrame.setVisible(true);
       myFrame.setResizable(true);
       
    }
    
    public JobApplicationTracker()
    {
        //sets the Title of the Frame
       setTitle("Job Application Tacker");
       //sets the background color
       setBackground(Color.cyan);
       
       SpringLayout myLayout = new SpringLayout();
       setLayout(myLayout);
       
       //Call the methods below to instantiate and place the various screen components 
       LocateLabels(myLayout);
       LocateTextFields(myLayout);
       LocateButtons(myLayout);
    }   
    
    //----------------------------------------------------------------------------------
    //Method that Manages the adding of multiple labels to the screen.
    //Each line requests that a LocateALabel method to instantiate, add and place a specific Label
    public void LocateLabels(SpringLayout myLabelLayout)
    {
        lblDate = LocateALabel (myLabelLayout, lblDate, "Date: ", 30,25);
        lblCompany = LocateALabel (myLabelLayout, lblCompany, "Company: ", 30,50);
        lblPhoneNumber = LocateALabel (myLabelLayout, lblPhoneNumber, "Phone Number: ", 30,75);
        lblEmail = LocateALabel (myLabelLayout, lblEmail, "Email: ", 30,100);
        lblAddress = LocateALabel (myLabelLayout, lblAddress, "Address: ", 30,125);
        lblDescription = LocateALabel (myLabelLayout, lblDescription, "Description", 30,150);
        lblFind = LocateALabel (myLabelLayout, lblFind, "Find: ", 30, 200);
    }
    /**
     * Method with low coupling and high cohesion
     *  for adding individual text boxes:
     *  -reduces overall code, especially in the 
     *      LocateLabels method
     *  -makes the method re-usable with minimal
     *      adjustment as it is moved from one 
     *      program to another
     */
    public Label LocateALabel(SpringLayout myLabelLayout, Label myLabel, String LabelCaption, int x, int y)
    {
        myLabel = new Label(LabelCaption);
        add(myLabel);
        myLabelLayout.putConstraint(SpringLayout.WEST, myLabel, x, SpringLayout.WEST, this);
        myLabelLayout.putConstraint(SpringLayout.NORTH, myLabel, y, SpringLayout.NORTH, this);
        return myLabel;
    }
    //----------------------------------------------------------------------------------
    //Method that Manages the adding of multiple TextFields to the screen.
    //Each line requests that a LocateATextFields method to instantiate, add and place a specific TextField
    public void LocateTextFields(SpringLayout myTextFieldLayout)
    {
        txtDate = LocateATextField(myTextFieldLayout, txtDate, 20, 130, 25);
        txtCompany = LocateATextField(myTextFieldLayout, txtCompany, 20, 130, 50);
        txtPhoneNumber = LocateATextField(myTextFieldLayout, txtPhoneNumber, 20, 130, 75);
        txtEmail = LocateATextField(myTextFieldLayout, txtEmail, 20, 130, 100);
        txtAddress = LocateATextField(myTextFieldLayout, txtAddress, 20, 130, 125);
        txtDescription = LocateATextField(myTextFieldLayout, txtDescription, 20, 130, 150);
        txtFind = LocateATextField(myTextFieldLayout, txtFind, 20, 130, 200); 
    }
    /**
     * Method with low coupling and high cohesion
     *  for adding individual text boxes:
     *  -reduces overall code, especially in the 
     *      LocateTextFields method
     *  -makes the method re-usable with minimal
     *      adjustment as it is moved from one 
     *      program to another
     */
    public TextField LocateATextField(SpringLayout myTextFieldLayout, TextField myTextField, int width, int x, int y)
    {
       myTextField = new TextField(width);
        add(myTextField);
        myTextFieldLayout.putConstraint(SpringLayout.WEST, myTextField, x, SpringLayout.WEST, this);
        myTextFieldLayout.putConstraint(SpringLayout.NORTH, myTextField, y, SpringLayout.NORTH, this);
        return myTextField; 
    }
    //----------------------------------------------------------------------------------
    //Method that Manages the adding of multiple Buttons to the screen.
    //Each line requests that a LocateAButton method to instantiate, add and place a specific Button
    public void LocateButtons(SpringLayout myButtonLayout)
    {
        btnNew = LocateAButton(myButtonLayout,btnNew, "New", 320, 25, 80, 25);
        btnSave = LocateAButton(myButtonLayout,btnSave, "Save", 320, 50, 80, 25);
        btnDelete = LocateAButton(myButtonLayout,btnDelete, "Delete", 320, 75, 80, 25);
        btnFind = LocateAButton(myButtonLayout,btnFind, "Find", 320, 100, 80, 25);
        btnExit = LocateAButton(myButtonLayout,btnExit, "Exit", 320, 170, 80, 25);
        btnFirst = LocateAButton(myButtonLayout,btnFirst, "|<", 140, 170, 30, 25);
        btnPrevious = LocateAButton(myButtonLayout,btnPrevious, "<", 180, 170, 30, 25);
        btnNext = LocateAButton(myButtonLayout,btnNext, ">", 220, 170, 30, 25);
        btnLast = LocateAButton(myButtonLayout,btnLast, ">|", 260, 170, 30, 25);
        
    }
    
    /**
     * Method with low coupling and high cohesion
     *  for adding individual text boxes:
     *  -reduces overall code, especially in the 
     *      LocateButtons method
     *  -makes the method re-usable with minimal
     *      adjustment as it is moved from one 
     *      program to another
     */
    
    public Button LocateAButton(SpringLayout myButtonLayout, Button myButton, String ButtonCaption, int x, int y, int w, int h)
    {
        myButton = new Button(ButtonCaption);
        add(myButton);
        myButton.addActionListener(this);
        myButtonLayout.putConstraint(SpringLayout.WEST, myButton, x, SpringLayout.WEST, this);
        myButtonLayout.putConstraint(SpringLayout.NORTH, myButton, y, SpringLayout.NORTH, this);
        myButton.setPreferredSize(new Dimension(w,h));
        return myButton;
    }
    
    /**
     *
     * @param e
     */
    public void actionPerformed(ActionEvent e)
    {
        // BUTTON FIRST
        if(e.getSource() == btnFirst)
        {
            // The currentEntry variable is used to define which record will be displayed on screen
            currentApplication = 0;
            //The displayEntry method will display the currentEntry on the screen
            displayEntry(currentApplication);
        }

        // BUTTON PREVIOUS
        if(e.getSource() == btnPrevious)
        {
            //Only go to previous record if we have a previous entry in the array...
            if(currentApplication > 0)
            {
                //Reduce the value of currentEntry by 1
                currentApplication--;
                //Display the current Entry
                displayEntry(currentApplication);
            }
        }

        // BUTTON NEXT
        if (e.getSource()== btnNext)
        {
            //Only go to the next entry if there is one existing in the array
            if(currentApplication < numberOfApplications - 1)
            {
                //Increase the value of currentEntry by 1
                currentApplication++;
                
                //Display the Current entry
                displayEntry(currentApplication);
            }
        }

        // BUTTON LAST
        if(e.getSource() == btnLast)
        {
            currentApplication = numberOfApplications - 1;
            displayEntry(currentApplication);
        }

        // BUTTON NEW
        if(e.getSource() == btnNew)
        {
             // Only if the array is large enough to store another record...
            if (numberOfApplications < maxApplications - 1)
            {
                // Increment the numberOfEntries
                numberOfApplications++;
                // Set the current entry to the new record
                currentApplication = numberOfApplications - 1;
                // Blank out any existing data in the 3 arrays, ready
                //       for adding the new record.
                applicationDate[currentApplication] = ""; 
                applicationCompany[currentApplication] = ""; 
                applicationPhoneNumber[currentApplication] = "";
                applicationEmail[currentApplication] = "";
                applicationAddress[currentApplication] = "";
                applicationDescription[currentApplication] = "";
                // Display this new blank entry on screen
                displayEntry(currentApplication);
            }
        }

        // BUTTON SAVE
        if(e.getSource() == btnSave)
        {
            // Call the saveEntry method that will copy the current
            //     TextField entries from the screen to the current
            //     record in the array in memory.
            saveEntry(currentApplication);
        }

        // BUTTON DELETE
        if(e.getSource()== btnDelete)
        {
            //Move all the later entries up one in the line each in the arry, covering over the current Entry in the proccess \
            for (int i = currentApplication; 1 < numberOfApplications - 1; i++)
            {
                applicationDate[i] = applicationDate[i + 1];
                applicationCompany[i] = applicationCompany[i + 1];
                applicationPhoneNumber[i] = applicationPhoneNumber[i + 1];
                applicationEmail[i] = applicationEmail[i + 1];
                applicationAddress[i] = applicationAddress[i + 1];
                applicationDescription[1] = applicationDescription[i + 1];
            }
            numberOfApplications--;
            if (currentApplication > numberOfApplications - 1);
            {
                currentApplication = numberOfApplications - 1;
            }
            displayEntry(currentApplication);
        }

        // BUTTON FIND
        if(e.getSource() == btnFind)
        { 
            // Declare a boolean valuable: found (to remember whether
            //         the required entry has been found yet.)
            boolean found = false;
			// Declare a counter (i)
            int i = 0;
            // While there are more entries to check and the 'search' entry has not been found... 
            while (i < numberOfApplications && found == false)
            {
                // If the current PCName is equal to the 'search' entry...
                if (applicationCompany[i].equals( txtFind.getText()))
                {
                    // Set found = true
                    found = true;
                }
                // Increment the counter (i) so the loop will move onto the next record
                i++;
            }
            // If the entry was found, then set the value of currentEntry and then display the entry.
            if (found) 
            {
                currentApplication = i - 1;
                displayEntry(currentApplication);
            }
        } 
        //BUTTON EXIT
        if(e.getSource() == btnExit)
        {
            
            System.exit(0);
        }
    }
    // Display the required data entry (record) int the Frame
    // The calling method must be specify the number (index) of the entry that this
    //      method needs to currently display on screen.
    public void displayEntry(int index)
    {
        //Take the required entry from the RecordName array and display it
        txtDate.setText(applicationDate[index]);
        txtCompany.setText(applicationCompany[index]);
        txtPhoneNumber.setText(applicationPhoneNumber[index]);
        txtEmail.setText(applicationEmail[index]);
        txtAddress.setText(applicationAddress[index]);
        txtDescription.setText(applicationDescription[index]);
    }
    // Take the current record displayed on screen and save it back into the 'currentEntry' position
    //      of the six arrays.
    public void saveEntry(int index)
    {
        //Take the current 
        applicationDate[index] = txtDate.getText();
        applicationCompany[index] = txtCompany.getText();
        applicationPhoneNumber[index] = txtPhoneNumber.getText();
        applicationEmail[index] = txtEmail.getText();
        applicationAddress[index] = txtAddress.getText();
        applicationDescription[index] = txtDescription.getText();
        writeFile();
    }
    //Read in the data from the data file - Birthdays.txt - one line at a time and store in the 6 arrays
    //Remeber the number of entries read in, in the global variable: numberOfBirthdays
    public void readFile()
    {
        // Try to read in the data and if an exception occurs go to the catch section
        try 
        {
            // Set up vaious streams for reading in the content of the data file.
            FileInputStream fstream = new FileInputStream("Applications.txt");
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            
            int i = 0;      // i is used as the line counter 
            String line;    // line is used to temporarily store the line read in from the data file
            
            // Read a line from the data file into the buffer and then check whether
            //      it is null.  The while loop continues until a line read in is null.
            while ((line = br.readLine()) != null)
            {
                // Split the line of data (from the text file) and put each entry into the
                //                                             temporary array - temp[]
                String[] temp = line.split(",");
                    
                applicationDate[i] = temp[0];        //Takes the first entry in temp and puts it in the recordName array at the current location
                applicationCompany[i] = temp[1];       //Takes the second entry in temp and puts it in the recordLikes array at the current location
                applicationPhoneNumber[i] = temp[2];    //Takes the third entry in temp and puts it in the recordDislikes array at the current location
                applicationEmail[i] = temp[3];         //Takes the fourth entry in temp and puts it in the recordDay array at the current location
                applicationAddress[i] = temp[4];       //Takes the fifth entry in temp and puts it in the recordMonth array at the current location
                applicationDescription[i] = temp[5];        //Takes the sixth entry in temp and puts it in the recordYear array at the current location
                    
                i++;    // Increment i so we can keep a count of how many entries have been read in.
            } 
            numberOfApplications = i;  // Set numberOfEntries equal to i, so as to remember how many entries are now in the arrays 
            
            br.close();         //close the BufferedReader
            in.close();         //close the DataInputStream
            fstream.close();    //close the FileInputStream
        }
        catch (Exception e)
        {
            //If an exception occurs, print an error message on the console
            System.err.println("Error Reading File :" + e.getMessage());
        }
    }
    
    // Write the data back out to the data file - one line at a time
    // Note: You may wish to use a different data file name while initially
    //       developing, so as not to accidently corrupt your input file.
    public void writeFile()
    {
        // Try to print out the data and if an exception occurs go to the Catch section 
        try
        {
            // After testing has been completed, replace the hard-coded filename: "Birthdays_New.txt"
            //       with the parameter variable: fileName 
            // Set up a PrintWriter for printing the array content out to the data file.
            PrintWriter out = new PrintWriter(new FileWriter("Applications.txt"));
            
            // Print out each line of the array into your data file.
            // Each line is printed out in the format:  recordName, recordLikes, recordDislikes, recordDay , recordMoth, recordYear
            for(int m = 0; m < numberOfApplications; m++){
                out.println(applicationDate[m] +"," +applicationCompany[m] + "," + applicationPhoneNumber[m] + "," + applicationEmail[m] + "," + applicationAddress[m] + "," + applicationDescription[m]);
            }

            // Close the printFile (and in so doing, empty the print buffer)
             out.close();
        }
        catch (Exception e)
        {
            // If an exception occurs, print an error message on the console.
            System.err.println("Error Writing File: " + e.getMessage());
        }
    }
    // Manage responses to the various window events
    
    
    public void windowClosing(WindowEvent e)
    {
        // Call the method below that reads the data from the data file (when the Frame first opens
        writeFile();
        // Exit the Frame
        System.exit(0);
    }
    
   
    public void windowIconified(WindowEvent e)
    {
    }

    
    public void windowOpened(WindowEvent e)
    {
        // call the method below that reads the data from the data file(when the Frame first opens
        readFile();
        // display the first data entry (record) in the frame
        displayEntry(currentApplication);
    }

   
    public void windowClosed(WindowEvent e)
    {
    }

   
    public void windowDeiconified(WindowEvent e)
    {
    }

    
    public void windowActivated(WindowEvent e)
    {
    }

    
    public void windowDeactivated(WindowEvent e)
    {
    }
    
}
